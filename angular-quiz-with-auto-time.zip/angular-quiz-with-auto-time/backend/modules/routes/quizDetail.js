const express = require('express');
const router = express.Router();
const quizDetailModel = require('../models/quizDetail');

// **************************Quiz Detail section
router.get('/get-quiz-detail', async (req, res, next) => {
    try {
      const quizDetail = await quizDetailModel.find({quizId:1});
      res.json({ quizDetail: quizDetail });
    } catch (error) {
      console.log(error);
    }
  });
  router.post('/add-quiz-detail', async (req, res, next) => {
    var quizId = req.body.quizId;
    var className = req.body.className;
    var subjectName = req.body.subjectName;
    var quizTitle = req.body.quizTitle;
    try {
      const addQuiz = {
        quizId: quizId,
        className: className,
        subjectName: subjectName,
        quizTitle: quizTitle,
        totalQuestion: req.body.totalQuestion,
        timeDuration: req.body.timeDuration,
        dateTime:req.body.dateTime,
        quizStatus:req.body.quizStatus,
      }
      const quizDetail = await quizDetailModel.create(addQuiz);
      res.json(quizDetail);
    } catch (error) {
      console.log(error);
    }
  });

  module.exports = router;