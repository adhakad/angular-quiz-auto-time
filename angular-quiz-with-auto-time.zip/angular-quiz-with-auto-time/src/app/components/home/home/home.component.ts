import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormArray } from '@angular/forms';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  quizForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.quizForm = this.fb.group({
      dateTime: ['', Validators.required],
    })
  }
  
  quizSubmit() {
    if (this.quizForm.valid) {
      function toTimestamp(strDate){
        var datum = Date.parse(strDate);
        return datum/1000;
      }
      // console.log(`form - ${toTimestamp(this.quizForm.value.dateTime)}`);
      // console.log(this.quizForm.value.dateTime)
      
    }
  }
}
